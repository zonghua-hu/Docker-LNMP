
extern zend_class_entry *phalcon_http_response_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Http_Response_Exception);

