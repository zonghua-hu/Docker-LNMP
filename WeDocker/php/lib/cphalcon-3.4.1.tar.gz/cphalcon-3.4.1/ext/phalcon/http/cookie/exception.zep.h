
extern zend_class_entry *phalcon_http_cookie_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Http_Cookie_Exception);

